﻿// ============================================================================
// AdventureGame.Engine.Tests/Usings.cs
// ============================================================================
global using Microsoft.VisualStudio.TestTools.UnitTesting;
global using System.Text.Json;
global using AdventureGame.Engine.Models;
global using AdventureGame.Engine.Runtime; // only needed for GameSession tests