﻿// ==============================
// AdventureGame.Engine/Models/GamePack.cs
// ==============================
#nullable enable
using System.Collections.ObjectModel;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

namespace AdventureGame.Engine.Models;

public sealed class GamePack
{
    // ---- Metadata ----
    public string Name { get; set; } = "Untitled Game";
    public string Description { get; set; } = "";
    public string Version { get; set; } = "1.0.0";

    // ---- World/Grid ----
    public GridConfig Grid { get; set; } = new();

    // ---- Content ----
    public List<GameElement> Elements { get; } = new();
    public GamePackVfs Vfs { get; } = new();

    // ---- Indexes ----
    private ReadOnlyDictionary<ElementId, GameElement>? _byId;
    public IReadOnlyDictionary<ElementId, GameElement> ById
        => _byId ??= new ReadOnlyDictionary<ElementId, GameElement>(
               Elements.ToDictionary(e => e.Id, e => e));

    private Dictionary<GridPosition, Scene>? _sceneByCell;

    [JsonIgnore]
    public IReadOnlyList<Player> PlayerCandidates => Elements.OfType<Player>().ToList();

    public IEnumerable<IReadOnlyGameElement> AsReadOnly()
    {
        foreach (var e in Elements) yield return (IReadOnlyGameElement)e;
    }

    public void RebuildIndices()
    {
        _byId = null;
        _sceneByCell = null;
    }

    // ---- Grid helpers ----
    public bool TryGetSceneAt(GridPosition cell, out Scene? scene)
    {
        EnsureSceneIndex();
        return _sceneByCell!.TryGetValue(cell, out scene);
    }

    public IEnumerable<(Direction Dir, GridPosition Pos, Scene? Scene)> GetNeighbors(GridPosition cell)
    {
        EnsureSceneIndex();
        foreach (var dir in new[]
        {
            Direction.NorthWest, Direction.North, Direction.NorthEast,
            Direction.West,                      Direction.East,
            Direction.SouthWest, Direction.South, Direction.SouthEast,
            Direction.Up, Direction.Down
        })
        {
            var pos = new GridPosition(cell.X + GridNav.Delta(dir).X,
                                       cell.Y + GridNav.Delta(dir).Y,
                                       cell.Z + GridNav.Delta(dir).Z);
            _sceneByCell!.TryGetValue(pos, out var s);
            yield return (dir, pos, s);
        }
    }

    private void EnsureSceneIndex()
    {
        if (_sceneByCell is not null) return;
        _sceneByCell = new Dictionary<GridPosition, Scene>();
        foreach (var s in Elements.OfType<Scene>())
            foreach (var c in s.OccupiedCells())
                _sceneByCell[c] = s; // Validate prevents overlaps
    }

    // ---- Validation ----
    public void ValidateOrThrow(bool requireAtLeastOnePlayer = true)
    {
        if (string.IsNullOrWhiteSpace(Name))
            throw new InvalidOperationException("GamePack.Name is required.");
        if (Grid.CellSize.Length < 1 || Grid.CellSize.Width < 1 || Grid.CellSize.Height < 1)
            throw new InvalidOperationException("Grid.CellSize must be ≥ 1 in every axis.");

        // Id uniqueness
        if (Elements.Count != Elements.Select(e => e.Id).Distinct().Count())
            throw new InvalidOperationException("Duplicate ElementId detected.");

        // Element invariants
        foreach (var e in Elements) { e.OnDeserialized(); e.ValidateStatesOrThrow(); }

        // Build world occupancy
        var occ = new Dictionary<GridPosition, Scene>();
        var worldScenes = Elements.OfType<Scene>()
                                  .Where(s => s.Location.IsWorld && s.Location.TryGetPosition(out _))
                                  .ToList();

        if (worldScenes.Count == 0)
            throw new InvalidOperationException("At least one world Scene is required.");

        foreach (var s in worldScenes)
        {
            foreach (var cell in s.OccupiedCells())
            {
                if (occ.TryGetValue(cell, out var other))
                    throw new InvalidOperationException($"Scene '{s.Name}' overlaps scene '{other.Name}' at {cell}.");
                occ[cell] = s;
            }
        }

        // Entry must be occupied
        if (!occ.ContainsKey(Grid.Entry))
            throw new InvalidOperationException($"No world scene occupies the entry cell {Grid.Entry}.");

        // Embedded scenes must reference existing parent
        foreach (var s in Elements.OfType<Scene>().Where(s => s.Location.IsEmbedded))
        {
            if (!s.Location.TryGetParent(out var parentId) || !ById.ContainsKey(parentId))
                throw new InvalidOperationException($"Embedded scene '{s.Name}' must reference an existing parent.");
        }

        // Player candidates
        if (requireAtLeastOnePlayer && PlayerCandidates.Count == 0)
            throw new InvalidOperationException("At least one Player element is required.");

        // Exits
        foreach (var ex in Elements.OfType<Exit>())
        {
            // Exits should be embedded in a Scene
            if (!ex.Location.IsEmbedded || !ex.Location.TryGetParent(out var hostId) ||
                !ById.TryGetValue(hostId, out var host) || host is not Scene hostScene)
                throw new InvalidOperationException($"Exit '{ex.Name}' must be embedded in a valid Scene.");

            switch (ex.Mode)
            {
                case ExitMode.Directional:
                    if (ex.Direction is null)
                        throw new InvalidOperationException($"Directional exit '{ex.Name}' must specify Direction.");

                    // Auto-wire target if none and host is world
                    if (ex.Targets.Count == 0 && hostScene.Location.IsWorld)
                    {
                        var delta = GridNav.Delta(ex.Direction.Value);
                        Scene? neighbor = null;
                        foreach (var cell in hostScene.OccupiedCells()
                                                      .Select(c => new GridPosition(c.X + delta.X, c.Y + delta.Y, c.Z + delta.Z)))
                        {
                            if (occ.TryGetValue(cell, out var n))
                            {
                                if (neighbor is null) neighbor = n;
                                else if (!ReferenceEquals(neighbor, n))
                                    throw new InvalidOperationException($"Exit '{ex.Name}' toward {ex.Direction} is ambiguous (multiple neighbor scenes).");
                            }
                        }
                        if (neighbor is null)
                            throw new InvalidOperationException($"Exit '{ex.Name}' toward {ex.Direction} has no adjacent scene; add a target or create one.");
                        ex.Targets.Add(neighbor.Id);
                    }
                    break;

                case ExitMode.Custom:
                case ExitMode.Portal:
                    if (ex.Targets.Count == 0)
                        throw new InvalidOperationException($"Exit '{ex.Name}' ({ex.Mode}) must have at least one target.");
                    break;
            }
        }

        // VFS sanity
        Vfs.ValidateOrThrow();

        // Cache the occupancy index
        _sceneByCell = occ;
    }

    // ---- JSON I/O ----
    private static JsonSerializerOptions Options()
        => new()
        {
            WriteIndented = true,
            TypeInfoResolver = new DefaultJsonTypeInfoResolver() // honors JsonPolymorphic/DerivedType
        };

    public string ToJson() => JsonSerializer.Serialize(this, Options());

    public static GamePack FromJson(string json, bool requireAtLeastOnePlayer = true)
    {
        var pack = JsonSerializer.Deserialize<GamePack>(json, Options()) ?? new GamePack();
        pack.RebuildIndices();
        pack.ValidateOrThrow(requireAtLeastOnePlayer);
        return pack;
    }
}