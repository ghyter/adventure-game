﻿// ==============================
// File: AdventureGame.Engine.Models/GameElements.cs (UPDATED)
// ==============================
#nullable enable
using System.Collections.ObjectModel;
using System.Text.Json.Serialization;

namespace AdventureGame.Engine.Models;

// --- Keys ---
public static class FlagKeys
{
    public const string IsVisible = "isVisible";
    public const string IsMovable = "isMovable";
}
public static class PropertyKeys
{
    public const string DefaultState = "defaultState";
}


public readonly record struct Dimensions(int Length, int Width, int Height);

// --- Runner-facing (read-only) ---
public interface IReadOnlyGameElement
{
    ElementId Id { get; }
    string Kind { get; }

    string Name { get; }
    string Description { get; }

    // CHANGED: LocationId -> Location
    Location Location { get; }

    bool IsVisible { get; }

    IReadOnlyDictionary<string, bool> Aliases { get; }
    IReadOnlyDictionary<string, int> Attributes { get; }
    IReadOnlyDictionary<string, string?> Properties { get; }
    IReadOnlyDictionary<string, bool> Flags { get; }

    IReadOnlyDictionary<string, string> StateDescriptions { get; }

    string DefaultState { get; }
}

public interface IReadOnlyItem : IReadOnlyGameElement
{
    bool IsMovable { get; }
}

// --- Editor-facing (mutable) ---
public interface IMutableGameElement : IReadOnlyGameElement
{
    new string Name { get; set; }
    new string Description { get; set; }

    // CHANGED: LocationId -> Location
    new Location Location { get; set; }

    new Dictionary<string, bool> Aliases { get; }
    new Dictionary<string, int> Attributes { get; }
    new Dictionary<string, string?> Properties { get; }
    new Dictionary<string, bool> Flags { get; }

    new Dictionary<string, string> StateDescriptions { get; }

    new bool IsVisible { get; set; }
    new string DefaultState { get; set; }

    // State editor helpers
    bool TryAddState(string name, string description, bool setAsDefault = false);
    bool RemoveStateSafely(string name);
    bool TrySetDefaultState(string name);
    void SetStates(IEnumerable<KeyValuePair<string, string>> states, string defaultState);
}

// --- Base element ---
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(Scene), "scene")]
[JsonDerivedType(typeof(Item), "item")]
[JsonDerivedType(typeof(Npc), "npc")]
[JsonDerivedType(typeof(Player), "player")]
[JsonDerivedType(typeof(Exit), "exit")]
public abstract class GameElement : IMutableGameElement, IJsonOnDeserialized
{
    public ElementId Id { get; init; } = ElementId.New();
    public string Kind => GetType().Name.ToLowerInvariant();

    public string Name { get; set; } = "";
    public string Description { get; set; } = "";

    // CHANGED: default to OffMap (no placement)
    public Location Location { get; set; } = Location.OffMap();

    public Dictionary<string, bool> Aliases { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, int> Attributes { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, string?> Properties { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, bool> Flags { get; } = new(StringComparer.OrdinalIgnoreCase);

    public Dictionary<string, string> StateDescriptions { get; } = new(StringComparer.OrdinalIgnoreCase);

    protected GameElement()
    {
        if (!Flags.ContainsKey(FlagKeys.IsVisible)) Flags[FlagKeys.IsVisible] = true;
        if (!Properties.ContainsKey(PropertyKeys.DefaultState)) Properties[PropertyKeys.DefaultState] = "";
    }

    [JsonIgnore]
    public bool IsVisible
    {
        get => Flags.TryGetValue(FlagKeys.IsVisible, out var v) ? v : true;
        set => Flags[FlagKeys.IsVisible] = value;
    }

    // Default is backed by Properties["defaultState"]
    [JsonIgnore]
    public string DefaultState
    {
        get => Properties.TryGetValue(PropertyKeys.DefaultState, out var v) && !string.IsNullOrWhiteSpace(v) ? v!.Trim() : "";
        set => Properties[PropertyKeys.DefaultState] = value?.Trim() ?? "";
    }

    // --- State helpers (editor) ---
    public bool TryAddState(string name, string description, bool setAsDefault = false)
    {
        var key = (name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(key)) return false;
        StateDescriptions[key] = description ?? "";
        if (setAsDefault) DefaultState = key;
        return true;
    }

    public bool RemoveStateSafely(string name)
    {
        var key = (name ?? "").Trim();
        if (!StateDescriptions.ContainsKey(key)) return false;
        if (StateDescriptions.Count <= 1) return false; // forbid removing last
        if (string.Equals(DefaultState, key, StringComparison.OrdinalIgnoreCase)) return false; // forbid removing current default
        return StateDescriptions.Remove(key);
    }

    public bool TrySetDefaultState(string name)
    {
        var key = (name ?? "").Trim();
        if (!StateDescriptions.ContainsKey(key)) return false;
        DefaultState = key;
        return true;
    }

    public void SetStates(IEnumerable<KeyValuePair<string, string>> states, string defaultState)
    {
        StateDescriptions.Clear();
        foreach (var kv in states)
        {
            var key = (kv.Key ?? "").Trim();
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("State name cannot be empty/whitespace.", nameof(states));
            StateDescriptions[key] = kv.Value ?? "";
        }
        DefaultState = defaultState?.Trim() ?? "";
        ValidateStatesOrThrow(); // ensure invariants now
    }

    // JSON lifecycle
    public virtual void OnDeserialized()
    {
        if (!Flags.ContainsKey(FlagKeys.IsVisible)) Flags[FlagKeys.IsVisible] = true;
        if (!Properties.ContainsKey(PropertyKeys.DefaultState)) Properties[PropertyKeys.DefaultState] = "";
        if (Properties.TryGetValue(PropertyKeys.DefaultState, out var v) && v is not null)
            Properties[PropertyKeys.DefaultState] = v.Trim();
        // Location is validated by its JsonConverter shape.
    }

    // Invariants (required): ≥1 state, default present and valid
    public virtual void ValidateStatesOrThrow()
    {
        if (StateDescriptions.Count == 0)
            throw new InvalidOperationException($"At least one state is required for '{Name}'.");
        var def = DefaultState;
        if (string.IsNullOrWhiteSpace(def))
            throw new InvalidOperationException($"DefaultState (Properties[\"{PropertyKeys.DefaultState}\"]) must be set for '{Name}'.");
        if (!StateDescriptions.ContainsKey(def))
            throw new InvalidOperationException($"DefaultState '{def}' must exist in StateDescriptions for '{Name}'.");
    }

    // --- Read-only projections for Runner ---
    private ReadOnlyDictionary<string, bool>? _roAliases;
    private ReadOnlyDictionary<string, int>? _roAttributes;
    private ReadOnlyDictionary<string, string?>? _roProps;
    private ReadOnlyDictionary<string, bool>? _roFlags;
    private ReadOnlyDictionary<string, string>? _roStates;

    IReadOnlyDictionary<string, bool> IReadOnlyGameElement.Aliases => _roAliases ??= new(Aliases);
    IReadOnlyDictionary<string, int> IReadOnlyGameElement.Attributes => _roAttributes ??= new(Attributes);
    IReadOnlyDictionary<string, string?> IReadOnlyGameElement.Properties => _roProps ??= new(Properties);
    IReadOnlyDictionary<string, bool> IReadOnlyGameElement.Flags => _roFlags ??= new(Flags);
    IReadOnlyDictionary<string, string> IReadOnlyGameElement.StateDescriptions => _roStates ??= new(StateDescriptions);
}

// --- Concrete elements ---

/// Scenes can be placed on the world grid (Location.World) or embedded (Location.Embedded).
public sealed class Scene : GameElement
{
    // CHANGED: Dimensions -> ExtentInCells (grid cell span, default 1x1x1)
    private Dimensions _extent = new(Length: 1, Width: 1, Height: 1);
    public Dimensions ExtentInCells
    {
        get => _extent;
        set
        {
            // clamp to ≥ 1
            var l = Math.Max(1, value.Length);
            var w = Math.Max(1, value.Width);
            var h = Math.Max(1, value.Height);
            _extent = new Dimensions(l, w, h);
        }
    }

    /// Enumerate occupied world cells (only when Location.IsWorld).
    public IEnumerable<GridPosition> OccupiedCells()
    {
        if (!Location.IsWorld || !Location.TryGetPosition(out var pos)) yield break;
        for (var dx = 0; dx < ExtentInCells.Length; dx++)
            for (var dy = 0; dy < ExtentInCells.Width; dy++)
                for (var dz = 0; dz < ExtentInCells.Height; dz++)
                    yield return new GridPosition(pos.X + dx, pos.Y + dy, pos.Z + dz);
    }
}

public sealed class Item : GameElement, IReadOnlyItem
{
    public Item()
    {
        if (!Flags.ContainsKey(FlagKeys.IsMovable)) Flags[FlagKeys.IsMovable] = true;
    }

    [JsonIgnore]
    public bool IsMovable
    {
        get => Flags.TryGetValue(FlagKeys.IsMovable, out var v) && v;
        set => Flags[FlagKeys.IsMovable] = value;
    }

    bool IReadOnlyItem.IsMovable => IsMovable;

    public override void OnDeserialized()
    {
        base.OnDeserialized();
        if (!Flags.ContainsKey(FlagKeys.IsMovable)) Flags[FlagKeys.IsMovable] = true;
    }

    public override void ValidateStatesOrThrow()
    {
        base.ValidateStatesOrThrow();
        if (!Flags.ContainsKey(FlagKeys.IsMovable)) Flags[FlagKeys.IsMovable] = true;
    }
}

public sealed class Npc : GameElement { }
public sealed class Player : GameElement { }

// Travel types for exits
public enum ExitMode { Directional, Custom, Portal }

public sealed class Exit : GameElement
{
    public HashSet<ElementId> Targets { get; } = new();
    public IReadOnlyCollection<ElementId> TargetsReadOnly => Targets;

    // NEW: Mode + optional Direction + bidirectional hint + label (for UI)
    public ExitMode Mode { get; set; } = ExitMode.Directional;
    public Direction? Direction { get; set; } // only when Mode=Directional
    public bool IsBidirectional { get; set; } = false;

    public string? Label
    {
        get => Properties.TryGetValue("label", out var v) ? v : null;
        set => Properties["label"] = value;
    }
}
