﻿// ==============================
// AdventureGame.Engine/Models/Player.cs
// ==============================
namespace AdventureGame.Engine.Models.Elements;

public sealed class Player : GameElement {
}
