﻿// ==============================
// AdventureGame.Engine/Models/Npc.cs
// ==============================
namespace AdventureGame.Engine.Models.Elements;

public sealed class Npc : GameElement {
}
