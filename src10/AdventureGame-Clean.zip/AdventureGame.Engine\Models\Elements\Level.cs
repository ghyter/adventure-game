﻿// ==============================
// AdventureGame.Engine/Models/Item.cs
// ==============================
using AdventureGame.Engine.Helpers;
using System.Text.Json.Serialization;

namespace AdventureGame.Engine.Models.Elements;

public sealed class Level : GameElement
{
    public Level()
    {
    }
}
