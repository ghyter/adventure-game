﻿using System;

namespace AdventureGame.Engine.Plugins;

[AttributeUsage(AttributeTargets.Assembly)]
public sealed class AdventureGameAssemblyAttribute : Attribute
{
}