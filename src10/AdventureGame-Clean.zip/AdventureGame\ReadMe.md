## Licences

[https://huggingface.co/onnx-models/all-MiniLM-L6-v2-onnx](https://huggingface.co/onnx-models/all-MiniLM-L6-v2-onnx)

Binh Nguyen / binhcode25@gmail.com