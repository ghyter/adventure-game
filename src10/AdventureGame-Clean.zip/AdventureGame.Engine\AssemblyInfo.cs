﻿using AdventureGame.Engine.Plugins;

[assembly: AdventureGameAssembly]